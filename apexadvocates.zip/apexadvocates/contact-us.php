<?php
include('includes/config.php');

?>
<!DOCTYPE html>
<html lang="en">

<head>

    <!-- Google tag (gtag.js) -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-9Q2EBJD2ZH"></script>
    <script>
    window.dataLayer = window.dataLayer || [];

    function gtag() {
        dataLayer.push(arguments);
    }
    gtag('js', new Date());

    gtag('config', 'G-9Q2EBJD2ZH');
    </script>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>LeadZilla | Contact us</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/modern-business.css" rel="stylesheet">

</head>

<body>

    <!-- Navigation -->
    <?php include('includes/header.php');?>
    <!-- Page Content -->
    <p></p>
    <div class="container">
        <h1 class="row mb-4">Contact Us</h1>

        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="index.php">Home</a>
            </li>
            <li class="breadcrumb-item active">Contact</li>
        </ol>

        <!-- Intro Content -->
        <div class="row">
            <div class="row mb-4">
                <div class="col-md-6">
                    <p><strong>Address:</strong>&nbsp;<a href="https://maps.app.goo.gl/BnFeSxzdZL2oBCW1A"
                            target="_blank">Office no 202B, Town Square, New Airport Rd, Viman Nagar, Pune, Maharashtra
                            411014</a></p>
                    <p><strong>Phone Number:</strong>&nbsp;<a href="https://api.whatsapp.com/send?phone=917058026479"
                            target="_blank">+91-7058026479</a></p>
                    <p><strong>Email:</strong>&nbsp;<a
                            href="mailto:kunal.thakur@desteksolotuions.com">kunal.thakur@desteksolotuions.com</a></p>
                </div>
                <div class="col-md-6">
                    <iframe
                        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3782.1210921534184!2d73.90461347496418!3d18.56857868253437!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bc2c10dd00b97bd%3A0x7f177adafc9c36c3!2sDestek%20Infosolutions%20Pvt%20Ltd!5e0!3m2!1sen!2sin!4v1743790977504!5m2!1sen!2sin"
                        width="100%" height="300" allowfullscreen="" loading="lazy"
                        referrerpolicy="no-referrer-when-downgrade" style="border:0;">
                    </iframe>
                </div>
            </div>
        </div>
        <hr><br>

        <h1>Get in Touch</h1>
        <?php
// Initialize variables to avoid undefined variable notices
$msg = '';
$error = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the form fields
    $firstname = $_POST['firstname'] ?? '';
    $lastname = $_POST['lastname'] ?? '';
    $phone = $_POST['phone'] ?? '';
    $email = $_POST['email'] ?? '';
    $subject = $_POST['subject'] ?? '';
    $message = $_POST['message'] ?? '';
    $status = '1'; // default status

    // Simple validation
    if (empty($firstname) || empty($email) || empty($message)) {
        $error = "Please fill in all required fields.";
    } else {
        // Check connection (assumes $con is already defined)
        if ($con->connect_error) {
            $error = "Connection failed: " . $con->connect_error;
        } else {
            // Prepare & bind
            $stmt = $con->prepare("INSERT INTO tblenquiry (firstname, lastname, phone, email, subject, message, status) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("ssssssi", $firstname, $lastname, $phone, $email, $subject, $message, $status);

            if ($stmt->execute()) {
                $msg = "Form submitted successfully! Someone from our team will contact you shortly reagrding your request!";
            } else {
                $error = "Error: " . $stmt->error;
            }

            $stmt->close();
            $con->close();
        }
    }
}
?>
        <div class="left-text">
            <form method="POST" action="">
                <div class="row mrgn40">
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label>First Name</label>
                            <input type="text" name="firstname" id="firstname" value="" class="form-control">
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label>Last Name</label>
                            <input type="text" name="lastname" id="lastname" value="" class="form-control">
                        </div>
                    </div>
                </div>
                <div class="row mrgn40">
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label>Phone Number</label>
                            <input type="text" name="phone" id="phone" value="" class="form-control">
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label>Email </label>
                            <input type="email" name="email" id="email" value="" class="form-control">
                        </div>
                    </div>
                </div>
                <div class="row mrgn40">
                    <div class="col-sm-12">
                        <div class="form-group">
                            <label>Subject </label>
                            <div class="form-group">
                                <select class="form-control" name="subject" id="subject" style="padding:0px">
                                    <option value="">--Select--</option>
                                    <option value="General Enquiry">General Enquiry</option>
                                    <option value="Practice Area Related">Practice Area Related</option>
                                    <option value="Business Association">Business Association </option>
                                    <option value="Marketing Initiative">Marketing Initiative</option>
                                    <option value="Others">Others</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row mrgn40">
                    <div class="col-sm-12">
                        <div class="form-group">
                            <label>Message</label>
                            <textarea class="form-control" rows="5" name="message" id="message"></textarea>
                        </div>
                    </div>
                </div>
                <div class="row mrgn40">
                    <div class="col-sm-12 text-center">
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </div>
                <br>
                <!---Success Message--->
                <?php if ($msg) { ?>
                <div class="alert alert-success" role="alert">
                    <strong>Well done!</strong> <?php echo htmlentities($msg); ?>
                </div>
                <?php } ?>

                <!---Error Message--->
                <?php if ($error) { ?>
                <div class="alert alert-danger" role="alert">
                    <strong>Oh snap!</strong> <?php echo htmlentities($error); ?>
                </div>
                <?php } ?>
            </form>
        </div>
    </div>

    <!-- /.row -->

    </div>
    <!-- /.container -->

    <!-- Footer -->
    <?php include('includes/footer.php');?>



    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

</body>


</html>