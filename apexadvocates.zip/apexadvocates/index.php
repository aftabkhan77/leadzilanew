<?php
include('includes/config.php');

?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Apex Advocates</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/modern-business.css" rel="stylesheet">

    <!-- Owl Carousel CSS -->
    <link rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" />
    <link rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css" />

    <!-- jQuery (required for Owl Carousel) -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <!-- Owl Carousel JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>

    <style>
    /* The Modal (background) */
    .modal {
        display: none;
        /* Hidden by default */
        position: fixed;
        /* Stay in place */
        z-index: 1;
        /* Sit on top */
        padding-top: 100px;
        /* Location of the box */
        left: 0;
        top: 0;
        width: 100%;
        /* Full width */
        height: 100%;
        /* Full height */
        overflow: auto;
        /* Enable scroll if needed */
        background-color: rgb(0, 0, 0);
        /* Fallback color */
        background-color: rgba(0, 0, 0, 0.4);
        /* Black w/ opacity */
    }

    /* Modal Content */
    .modal-content {
        position: relative;
        background-color: #fefefe;
        margin: auto;
        padding: 0;
        border: 1px solid #888;
        width: 80%;
        box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
        -webkit-animation-name: animatetop;
        -webkit-animation-duration: 0.4s;
        animation-name: animatetop;
        animation-duration: 0.4s
    }

    .modal-content {
        /* background: white;
        border-radius: 8px;
        width: 90%; */
        max-width: 600px;
        max-height: 90vh;
        /* prevent it from going off-screen */
        display: flex;
        flex-direction: column;
        overflow: hidden;
    }

    /* .modal-header,
    .modal-footer {
        padding: 15px;
        background-color: #f1f1f1;
        flex-shrink: 0;
    } */

    .modal-body {
        padding: 15px;
        overflow-y: auto;
        flex-grow: 1;
        /* takes up remaining space */
    }


    /* Add Animation */
    @-webkit-keyframes animatetop {
        from {
            top: -300px;
            opacity: 0
        }

        to {
            top: 0;
            opacity: 1
        }
    }

    @keyframes animatetop {
        from {
            top: -300px;
            opacity: 0
        }

        to {
            top: 0;
            opacity: 1
        }
    }

    /* The Close Button */
    .close {
        color: white;
        float: right;
        font-size: 28px;
        font-weight: bold;
    }

    .close:hover,
    .close:focus {
        color: #000;
        text-decoration: none;
        cursor: pointer;
    }

    .modal-header {
        padding: 2px 16px;
        background-color: #00274D;
        color: white;
    }

    .modal-body {
        padding: 2px 16px;
    }

    .modal-footer {
        padding: 2px 16px;
        background-color: #00274D;
        color: white;
    }

    /* Testimonial Slider */
    .testimonial-slider {
        width: 100%;
        background: #fff;
        padding: 2rem;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
        border-radius: 24px;
        text-align: center;
        position: relative;
    }

    .testimonial-line {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 0.5rem;
        font-size: 1.2rem;
        color: #444;
        font-style: italic;
        text-align: center;
        margin-bottom: 1.5rem;
    }

    .quote-mark {
        font-size: 2rem;
        color: #ccc;
    }

    .profile {
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 0.5rem;
    }

    .profile img {
        width: 60px;
        height: 60px;
        border-radius: 50%;
        object-fit: cover;
        border: 2px solid #007bff;
    }

    .profile-name {
        font-weight: 600;
        color: #333;
    }

    .arrow {
        position: absolute;
        top: 50%;
        transform: translateY(-50%);
        font-size: 2rem;
        background: none;
        border: none;
        cursor: pointer;
        color: #007bff;
        padding: 0 1rem;
        user-select: none;
        transition: color 0.2s;
    }

    .arrow:hover {
        color: #0056b3;
    }

    .arrow-left {
        left: 0;
    }

    .arrow-right {
        right: 0;
    }

    /* Partner styling */
    .team-carousel {
        position: relative;
        overflow: hidden;
        max-width: 100%;
        padding: 20px 0;
    }

    .team-wrapper {
        display: flex;
        transition: transform 0.5s ease;
        gap: 20px;
    }

    .team-card {
        min-width: 200px;
        background: #fff;
        padding: 15px;
        border-radius: 10px;
        text-align: center;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        flex-shrink: 0;
    }

    .team-photo {
        width: 80px;
        height: 80px;
        border-radius: 50%;
        object-fit: cover;
        margin-bottom: 10px;
    }

    .team-name {
        font-weight: bold;
        font-size: 16px;
        margin: 5px 0;
    }

    .team-designation {
        font-size: 14px;
        color: #555;
    }

    .team-email {
        display: inline-block;
        margin-top: 8px;
        color: #007BFF;
        text-decoration: none;
        font-size: 14px;
    }

    .team-prev,
    .team-next {
        position: absolute;
        top: 50%;
        transform: translateY(-50%);
        font-size: 24px;
        background: none;
        border: none;
        cursor: pointer;
        color: #333;
    }

    .team-prev {
        left: 5px;
    }

    .team-next {
        right: 5px;
    }

    @media (max-width: 768px) {
        .team-card {
            min-width: 90%;
            /* show one card at a time */
        }

        .team-wrapper {
            gap: 10px;
        }

        .team-prev,
        .team-next {
            font-size: 30px;
            top: 45%;
        }
    }

    .team-wrapper {
        display: flex;
        transition: transform 0.5s ease;
        gap: 20px;
        justify-content: flex-start;
        /* default */
    }

    /* Practices Listing */

    .practices-section {
        max-width: 1200px;
        margin: 0 auto;
    }

    .practices-title {
        text-align: center;
        font-size: 2rem;
        font-weight: 600;
        position: relative;
        margin-bottom: 40px;
    }

    .practices-title::after {
        content: "";
        display: block;
        height: 2px;
        width: 60px;
        background-color: #1e2b3c;
        margin: 8px auto 0;
    }

    .practices-grid {
        display: flex;
        flex-wrap: wrap;
        justify-content: space-between;
        gap: 30px 0;
        border-top: 1px solid #ddd;
        padding-top: 30px;
    }

    .practice-card {
        width: 32%;
        display: flex;
        gap: 20px;
        align-items: flex-start;
        position: relative;
    }

    .practice-icon {
        flex-shrink: 0;
        background-color: #f1f1f1;
        border-radius: 50%;
        width: 60px;
        height: 60px;
        display: flex;
        justify-content: center;
        align-items: center;
        font-size: 28px;
        color: #333;
        position: relative;
    }

    .practice-line {
        position: absolute;
        top: 60px;
        left: 29px;
        width: 2px;
        height: 60px;
        background-color: #ccc;
    }

    .practice-info h4 {
        margin: 0 0 5px;
        font-weight: 600;
        font-size: 1.05rem;
    }

    .practice-info p {
        margin: 0 0 10px;
        font-size: 0.95rem;
        line-height: 1.4;
    }

    .practice-info a {
        font-size: 0.9rem;
        text-decoration: none;
        color: #1e2b3c;
        font-weight: 600;
    }

    .practice-info a::after {
        content: ' ➔';
        font-weight: normal;
    }

    @media (max-width: 1024px) {
        .practice-card {
            width: 48%;
        }
    }

    @media (max-width: 768px) {
        .practice-card {
            width: 100%;
        }
    }
    </style>

</head>

<body>

    <!-- Navigation -->
    <?php include('includes/header.php');?>
    <!-- Page Content -->
    <div class="container">

        <?php 
$pagetype='blogs';
$query=mysqli_query($con,"select PageTitle,Description from tblpages where PageName='$pagetype'");
while($row=mysqli_fetch_array($query))

?>

        <!-- The Modal -->
        <div id="myModal" class="modal" style="display: none;">
            <!-- Modal shows on load -->
            <div class="modal-content">
                <div class="modal-header">
                    <h2>DISCLAIMER</h2>
                </div>
                <div class="modal-body">
                    <p>The rules of the Bar Council of India prohibit law firms from soliciting work or advertising in
                        any manner. By clicking on 'I AGREE', the user acknowledges that:</p>
                    <ul>
                        <li>The user wishes to gain more information about Apex Advocates and its practice areas and its
                            attorneys, for his/her own information and use;</li>
                        <li>The information is made available/provided to the user only on his/her specific request and
                            any information obtained or material downloaded from this website is completely at the
                            user's volition and any transmission, receipt or use of this site is not intended to, and
                            will not, create any lawyer-client relationship; and</li>
                        <li>None of the information contained on the website is in the nature of a legal opinion or
                            otherwise amounts to any legal advice.</li>
                    </ul>
                    <p>Apex Advocates is not liable for any consequence of any action taken by the user relying on
                        material/information provided under this website. In cases where the user has any legal issues,
                        he/she in all cases must seek independent legal advice.</p>
                </div>
                <div class="modal-footer">
                    <button id="agreeBtn" class="btn btn-primary">I AGREE</button>
                </div>
            </div>
        </div>

        <!-- <script>
        // Show modal on page load
        window.onload = function() {
            var modal = document.getElementById("myModal");
            modal.style.display = "block";

            // Close modal on "I AGREE" click
            document.getElementById("agreeBtn").onclick = function() {
                modal.style.display = "none";
            };

            // Optional: Close when clicking outside modal
            window.onclick = function(event) {
                if (event.target == modal) {
                    modal.style.display = "none";
                }
            };
        };
        </script> -->

        <!-- JavaScript -->
        <!-- <script>
        document.addEventListener("DOMContentLoaded", function() {
            const modal = document.getElementById("disclaimerModal");
            const agreeBtn = document.getElementById("agreeBtn");

            // Check if already agreed
            if (!localStorage.getItem("disclaimerAgreed")) {
                modal.style.display = "block";
            }

            agreeBtn.addEventListener("click", function() {
                localStorage.setItem("disclaimerAgreed", "true");
                modal.style.display = "none";
            });
        });
        </script> -->


        <script>
        document.addEventListener("DOMContentLoaded", function() {
            const modal = document.getElementById("myModal");
            const agreeBtn = document.getElementById("agreeBtn");

            // Show modal only once per tab/session
            if (!sessionStorage.getItem("disclaimerAgreed")) {
                modal.style.display = "block";
            }

            agreeBtn.addEventListener("click", function() {
                sessionStorage.setItem("disclaimerAgreed", "true");
                modal.style.display = "none";
            });

            // Optional: Close when clicking outside modal
            window.onclick = function(event) {
                if (event.target === modal) {
                    modal.style.display = "none";
                }
            };
        });
        </script>


        <div class="wow fadeInLeft animated" data-wow-duration="2s"
            style="visibility: visible;-webkit-animation-duration: 2s; -moz-animation-duration: 2s; animation-duration: 2s;">
            <br><img src="images/BG.png" alt="Apex Advocates Logo" style="width:100%"><br>
            <h2 class="practices-title">WHO ARE WE</h2>
            <div class="left-text">
                <p class="MsoNormal"
                    style="margin-bottom: 7.5pt; line-height: 18pt; text-align: justify; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;">
                    <span
                        style="font-size: 12pt; font-family: Arial, &quot;sans-serif&quot;; color: rgb(68, 73, 86);">Apex
                        Advocates is a leading full service/multi-disciplinary Indian law firm offering transactional,
                        regulatory,
                        advisory and dispute resolution. With its Principal Office in Pune, Maharashtra, the firm
                        advises a diverse
                        clientele including domestic and international companies, banks and financial institutions,
                        funds,
                        promoter groups, and public sector undertakings.</span>
                </p>
                <p class="MsoNormal"
                    style="margin-bottom: 7.5pt; line-height: 18pt; text-align: justify; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;">
                    <span
                        style="font-size: 12pt; font-family: Arial, &quot;sans-serif&quot;; color: rgb(68, 73, 86);">Set
                        up with a desire to bring client service into sharper focus, to provide commercially viable
                        legal advice
                        and committed legal representation to our clients across all sectors; the firm has successfully
                        been able to
                        establish its identity outside its origins, dealing with significant depth in complex domestic
                        and
                        international matters.</span>
                </p>
                <p class="MsoNormal"
                    style="margin-bottom: 7.5pt; line-height: 18pt; text-align: justify; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;">
                    <span
                        style="font-size: 12pt; font-family: Arial, &quot;sans-serif&quot;; color: rgb(68, 73, 86);">Our
                        team of well qualified and experienced lawyers bring entrepreneurial energy to work together
                        with shared
                        values for greater standards of service with a high degree of professionalism and
                        responsiveness.</span>
                </p>
                <p class="MsoNormal"
                    style="margin-bottom: 7.5pt; line-height: 18pt; text-align: justify; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;">
                    <span
                        style="font-size: 12pt; font-family: Arial, &quot;sans-serif&quot;; color: rgb(68, 73, 86);">What
                        distinguishes the firm from its peers is the approach which is:</span>
                </p>
                <ul>
                    <li
                        style="margin-bottom: 7.5pt; text-align: justify; line-height: 18pt; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;">
                        <span
                            style="text-indent: -18pt; font-size: 12pt; font-family: Arial, &quot;sans-serif&quot;; color: rgb(68, 73, 86);">High
                            Degree of Partner Involvement and Availability – We assure to our clients, partner
                            involvement in all deals
                            and transactions, at all times.</span>
                    </li>
                    <li
                        style="margin-bottom: 7.5pt; text-align: justify; line-height: 18pt; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;">
                        <span
                            style="color: rgb(68, 73, 86); font-family: Arial, &quot;sans-serif&quot;; font-size: 12pt; text-indent: -18pt;">High
                            Quality Legal Advice – We deliver services of the highest quality, which are capable of
                            meeting the most
                            exacting standards.</span>
                    </li>
                    <li
                        style="margin-left: 0cm; text-align: justify; text-indent: -18pt; line-height: 18pt; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;">
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span
                            style="color: rgb(68, 73, 86); font-family: Arial, &quot;sans-serif&quot;; font-size: 12pt; text-indent: -18pt;">Availability
                            and Responsiveness – We are proactive in our approach and are available to our clients at
                            all times.</span>
                    </li>
                    <li
                        style="margin-left: 0cm; text-align: justify; text-indent: -18pt; line-height: 18pt; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;">
                        &nbsp;&nbsp;&nbsp;&nbsp;<span
                            style="color: rgb(68, 73, 86); font-family: Arial, &quot;sans-serif&quot;; font-size: 12pt;">Legal
                            Research
                            and Analysis Based Advisory – We keep abreast with market practices applicable to legal
                            interpretation, and
                            adopt/recommend such practices only if they are supported by the prevailing legal and
                            regulatory
                            framework.</span></li>
                </ul>
            </div>
            <hr>
            <div class="left-text">
                <div class="practices-section">
                    <h2 class="practices-title">OUR PRACTICES</h2>
                    <div class="practices-grid">

                        <div class="practice-card">
                            <div class="practice-icon">🏦</div>
                            <div class="practice-line"></div>
                            <div class="practice-info">
                                <h4><em>Intellectual Property</em></h4>
                                <p>Intellectual Property is one of our core and highly recognised areas of expertise.
                                </p>
                                <a href="intellectual-property.php">READ MORE</a>
                            </div>
                        </div>

                        <div class="practice-card">
                            <div class="practice-icon">📝</div>
                            <div class="practice-line"></div>
                            <div class="practice-info">
                                <h4><em>Corporate Commercial</em></h4>
                                <p>One of our key practice areas is corporate and commercial, which extends to various
                                    sectors.</p>
                                <a href="corporate-commercial.php">READ MORE</a>
                            </div>
                        </div>

                        <div class="practice-card">
                            <div class="practice-icon">🤝</div>
                            <div class="practice-line"></div>
                            <div class="practice-info">
                                <h4><em>Dispute Resolution</em></h4>
                                <p>We work virtually in every area of dispute resolution and litigation strategy.</p>
                                <a href="dispute-resolution.php">READ MORE</a>
                            </div>
                        </div>

                        <div class="practice-card">
                            <div class="practice-icon">☂️</div>
                            <div class="practice-line"></div>
                            <div class="practice-info">
                                <h4><em>Litigation</em></h4>
                                <p>Our litigation practice is seen as a market leader. We advise clients on the entire
                                    gamut.</p>
                                <a href="litigation.php">READ MORE</a>
                            </div>
                        </div>

                        <!-- <div class="practice-card">
                            <div class="practice-icon">💧</div>
                            <div class="practice-line"></div>
                            <div class="practice-info">
                                <h4><em>Energy, Oil and Gas</em></h4>
                                <p>We have significant experience and expertise in the Energy, Oil & Gas sector.</p>
                                <a href="#">READ MORE</a>
                            </div>
                        </div> -->

                        <div class="practice-card">
                            <div class="practice-icon">🏠</div>
                            <div class="practice-line"></div>
                            <div class="practice-info">
                                <h4><em>Real Estate</em></h4>
                                <p>We advise clients on increasingly diverse and complex matters in the real estate
                                    space.</p>
                                <a href="#">READ MORE</a>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
            <hr>
            <div class="left-text">
                <h2 class="practices-title">OUR PARTNERS</h2>
                <div class="team-carousel">
                    <div class="team-wrapper">
                        <!-- JS will populate cards here -->
                    </div>
                    <button class="team-prev" onclick="prevSlide()">&#10094;</button>
                    <button class="team-next" onclick="nextSlide()">&#10095;</button>
                </div>

                <script>
                const teamMembers = [{
                        name: "Anirudha Kotgire",
                        designation: "Partner",
                        email: "anirudha@desteksolutions.com",
                        photo: "images/Partners/anirudha_kotgire.png"
                    },
                    {
                        name: "Mandar Lande",
                        designation: "Partner",
                        email: "mandar@desteksolutions.com",
                        photo: "images/Partners/mandar_lande.png"
                    },
                    {
                        name: "Kunal Thakur",
                        designation: "Chief Legal Counsel",
                        email: "kunal.thakur@desteksolutions.com",
                        photo: "images/Partners/kunal_thakur.png"
                    }
                ];

                const wrapper = document.querySelector('.team-wrapper');
                let currentIndex = 0;

                function getVisibleCount() {
                    return window.innerWidth <= 768 ? 1 : teamMembers.length < 5 ? teamMembers.length : 5;
                }

                function renderCarousel() {
                    wrapper.innerHTML = '';
                    teamMembers.forEach(member => {
                        const card = document.createElement('div');
                        card.className = 'team-card';
                        card.innerHTML = `
            <img class="team-photo" src="${member.photo}" alt="${member.name}">
            <div class="team-name">${member.name}</div>
            <div class="team-designation">${member.designation}</div>
            <a class="team-email" href="mailto:${member.email}">Email</a>
        `;
                        wrapper.appendChild(card);
                    });

                    // Center if fewer than visible count
                    wrapper.style.justifyContent = (teamMembers.length <= getVisibleCount()) ? 'center' : 'flex-start';
                    updateCarouselPosition();
                }

                function updateCarouselPosition() {
                    const slideWidth = wrapper.querySelector('.team-card')?.offsetWidth || 0;
                    wrapper.style.transform = `translateX(-${currentIndex * (slideWidth + 20)}px)`; // 20 is the `gap`
                }

                function nextSlide() {
                    const visibleCount = getVisibleCount();
                    if (currentIndex + visibleCount < teamMembers.length) {
                        currentIndex++;
                        updateCarouselPosition();
                    }
                }

                function prevSlide() {
                    if (currentIndex > 0) {
                        currentIndex--;
                        updateCarouselPosition();
                    }
                }

                // Optional: Auto-scroll every 5 seconds
                let autoScroll = setInterval(() => {
                    const visibleCount = getVisibleCount();
                    if (currentIndex + visibleCount < teamMembers.length) {
                        nextSlide();
                    } else {
                        currentIndex = 0;
                        updateCarouselPosition();
                    }
                }, 5000);

                // Init
                renderCarousel();
                window.addEventListener('resize', () => {
                    currentIndex = 0;
                    renderCarousel();
                });
                </script>
            </div>

            <hr>
            <div class="item active">
                <div class="testimonial-slider">
                    <button class="arrow arrow-left" onclick="prevTestimonial()">&#8249;</button>
                    <button class="arrow arrow-right" onclick="nextTestimonial()">&#8250;</button>

                    <div class="testimonial-line">
                        <span class="quote-mark">❝</span>
                        <span class="testimonial-text" id="testimonial"></span>
                        <span class="quote-mark">❞</span>
                    </div>
                    <div class="profile">
                        <img id="testimonialPhoto" src="" alt="Profile Photo" style="display: none;">
                        <div class="profile-name" id="testimonialName"></div>
                    </div>
                </div>

                <script>
                const testimonials = [{
                        text: "Sharp, reliable, and extremely professional. We worked with Apex Advocates for our startup's IP registration, and the process was smooth and transparent throughout. Their deep understanding of intellectual property rights really stood out.",
                        name: "Rohan Mehta, Founder, TechSpark Innovations"
                        // ,photo: "https://randomuser.me/api/portraits/men/32.jpg"
                    },
                    {
                        text: "Apex Advocates truly came through for us. In a complicated real estate dispute, their litigation team guided us strategically and ensured a favorable outcome. Highly recommend them for real estate and property matters!",
                        name: "Anjali Shah, Real Estate Developer"
                        // ,photo: "https://randomuser.me/api/portraits/women/44.jpg"
                    },
                    {
                        text: "Even though the firm is new, the experience shows. We partnered with Apex Advocates for corporate structuring and legal compliance. Their advice was spot-on and saved us from potential legal hurdles down the road.",
                        name: "Amit Vora, CFO, LignoTech Solutions"
                        // ,photo: "https://randomuser.me/api/portraits/men/76.jpg"
                    },
                    {
                        text: "What impressed me most was their responsiveness. Whether it was drafting contracts or negotiating during a commercial dispute, they were quick, well-prepared, and always had our best interests in mind.",
                        name: "Sneha Rajan, Director, Solstice Retail Pvt. Ltd."
                        // ,photo: "https://randomuser.me/api/portraits/women/65.jpg"
                    },
                    {
                        text: "Efficient, experienced, and always a step ahead. Apex Advocates handled our trademark and copyright filings seamlessly. You can tell they have solid IP law experience.",
                        name: "Kapil Nair, Artist & Content Creator"
                        // ,photo: "https://randomuser.me/api/portraits/men/88.jpg"
                    }
                ];

                let index = 0;

                const testimonialText = document.getElementById('testimonial');
                const testimonialName = document.getElementById('testimonialName');
                const testimonialPhoto = document.getElementById('testimonialPhoto');

                function showTestimonial(i) {
                    testimonialText.style.opacity = 0;
                    testimonialName.style.opacity = 0;
                    testimonialPhoto.style.opacity = 0;

                    setTimeout(() => {
                        testimonialText.textContent = testimonials[i].text;
                        testimonialName.textContent = testimonials[i].name;
                        testimonialPhoto.src = testimonials[i].photo;

                        testimonialText.style.opacity = 1;
                        testimonialName.style.opacity = 1;
                        testimonialPhoto.style.opacity = 1;
                    }, 300);
                }

                function nextTestimonial() {
                    index = (index + 1) % testimonials.length;
                    showTestimonial(index);
                }

                function prevTestimonial() {
                    index = (index - 1 + testimonials.length) % testimonials.length;
                    showTestimonial(index);
                }

                // Initialize
                showTestimonial(index);

                // Autoplay every 5 seconds
                setInterval(nextTestimonial, 5000);
                </script>
            </div>
            <hr>
            <?php
// Initialize variables to avoid undefined variable notices
$msg = '';
$error = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the form fields
    $firstname = $_POST['firstname'] ?? '';
    $lastname = $_POST['lastname'] ?? '';
    $phone = $_POST['phone'] ?? '';
    $email = $_POST['email'] ?? '';
    $subject = $_POST['subject'] ?? '';
    $message = $_POST['message'] ?? '';
    $status = '1'; // default status

    // Simple validation
    if (empty($firstname) || empty($email) || empty($message)) {
        $error = "Please fill in all required fields.";
    } else {
        // Check connection (assumes $con is already defined)
        if ($con->connect_error) {
            $error = "Connection failed: " . $con->connect_error;
        } else {
            // Prepare & bind
            $stmt = $con->prepare("INSERT INTO tblenquiry (firstname, lastname, phone, email, subject, message, status) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("ssssssi", $firstname, $lastname, $phone, $email, $subject, $message, $status);

            if ($stmt->execute()) {
                $msg = "Form submitted successfully! Someone from our team will contact you shortly reagrding your request!";
            } else {
                $error = "Error: " . $stmt->error;
            }

            $stmt->close();
            $con->close();
        }
    }
}
?>
            <div class="left-text">
                <h2 class="practices-title">CONTACT US</h2>
                <form method="POST" action="">
                    <div class="row mrgn40">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>First Name</label>
                                <input type="text" name="firstname" id="firstname" value="" class="form-control">
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>Last Name</label>
                                <input type="text" name="lastname" id="lastname" value="" class="form-control">
                            </div>
                        </div>
                    </div>
                    <div class="row mrgn40">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>Phone Number</label>
                                <input type="text" name="phone" id="phone" value="" class="form-control">
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>Email </label>
                                <input type="email" name="email" id="email" value="" class="form-control">
                            </div>
                        </div>
                    </div>
                    <div class="row mrgn40">
                        <div class="col-sm-12">
                            <div class="form-group">
                                <label>Subject </label>
                                <div class="form-group">
                                    <select class="form-control" name="subject" id="subject" style="padding:0px">
                                        <option value="">--Select--</option>
                                        <option value="General Enquiry">General Enquiry</option>
                                        <option value="Practice Area Related">Practice Area Related</option>
                                        <option value="Business Association">Business Association </option>
                                        <option value="Marketing Initiative">Marketing Initiative</option>
                                        <option value="Others">Others</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row mrgn40">
                        <div class="col-sm-12">
                            <div class="form-group">
                                <label>Message</label>
                                <textarea class="form-control" rows="5" name="message" id="message"></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="row mrgn40">
                        <div class="col-sm-12 text-center">
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
                    </div>
                    <br>
                    <!---Success Message--->
                    <?php if ($msg) { ?>
                    <div class="alert alert-success" role="alert">
                        <strong>Well done!</strong> <?php echo htmlentities($msg); ?>
                    </div>
                    <?php } ?>

                    <!---Error Message--->
                    <?php if ($error) { ?>
                    <div class="alert alert-danger" role="alert">
                        <strong>Oh snap!</strong> <?php echo htmlentities($error); ?>
                    </div>
                    <?php } ?>
                </form>
            </div>
        </div>
        <!-- <div class="left-text">A product of <a href="https://desteksolutions.com/">Destek Infosolutions</a>&nbsp;. -->
    </div>
    </div>

    </div>
    <!-- /.container -->

    <!-- Footer -->
    <?php include('includes/footer.php');?>



    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>

    <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" rel="stylesheet"> -->

    <script>
    $(document).ready(function() {
        $(".partners-carousel").owlCarousel({
            loop: true,
            margin: 20,
            nav: true,
            dots: false,
            responsive: {
                0: {
                    items: 1
                },
                600: {
                    items: 2
                },
                1000: {
                    items: 5
                } // Adjust for large screens
            }
        });
    });
    </script>

</body>

</html>