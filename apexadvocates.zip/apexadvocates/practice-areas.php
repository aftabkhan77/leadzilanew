<?php
include('includes/config.php');

?>
<!DOCTYPE html>
<html lang="en">

<head>

    <!-- Google tag (gtag.js) -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-9Q2EBJD2ZH"></script>
    <script>
    window.dataLayer = window.dataLayer || [];

    function gtag() {
        dataLayer.push(arguments);
    }
    gtag('js', new Date());

    gtag('config', 'G-9Q2EBJD2ZH');
    </script>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Apex Advocates | Practice Areas</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/modern-business.css" rel="stylesheet">
    <style>
    /* Practices Listing */

    .practices-section {
        max-width: 1200px;
        margin: 0 auto;
    }

    .practices-title {
        text-align: center;
        font-size: 2rem;
        font-weight: 600;
        position: relative;
        margin-bottom: 40px;
    }

    .practices-title::after {
        content: "";
        display: block;
        height: 2px;
        width: 60px;
        background-color: #1e2b3c;
        margin: 8px auto 0;
    }

    .practices-grid {
        display: flex;
        flex-wrap: wrap;
        justify-content: space-between;
        gap: 30px 0;
        border-top: 1px solid #ddd;
        padding-top: 30px;
    }

    .practice-card {
        width: 32%;
        display: flex;
        gap: 20px;
        align-items: flex-start;
        position: relative;
    }

    .practice-icon {
        flex-shrink: 0;
        background-color: #f1f1f1;
        border-radius: 50%;
        width: 60px;
        height: 60px;
        display: flex;
        justify-content: center;
        align-items: center;
        font-size: 28px;
        color: #333;
        position: relative;
    }

    .practice-line {
        position: absolute;
        top: 60px;
        left: 29px;
        width: 2px;
        height: 60px;
        background-color: #ccc;
    }

    .practice-info h4 {
        margin: 0 0 5px;
        font-weight: 600;
        font-size: 1.05rem;
    }

    .practice-info p {
        margin: 0 0 10px;
        font-size: 0.95rem;
        line-height: 1.4;
    }

    .practice-info a {
        font-size: 0.9rem;
        text-decoration: none;
        color: #1e2b3c;
        font-weight: 600;
    }

    .practice-info a::after {
        content: ' ➔';
        font-weight: normal;
    }

    @media (max-width: 1024px) {
        .practice-card {
            width: 48%;
        }
    }

    @media (max-width: 768px) {
        .practice-card {
            width: 100%;
        }
    }
    </style>
</head>

<body>

    <!-- Navigation -->
    <?php include('includes/header.php');?>
    <!-- Page Content -->
    <br><br>
    <div class="container">
        <div class="left-text">
            <div class="practices-section">
                <h2 class="practices-title">OUR PRACTICES</h2>
                <div class="practices-grid">

                    <div class="practice-card">
                        <div class="practice-icon">🏦</div>
                        <div class="practice-line"></div>
                        <div class="practice-info">
                            <h4><em>Intellectual Property</em></h4>
                            <p>Intellectual Property is one of our core and highly recognised areas of expertise.</p>
                            <a href="intellectual-property.php">READ MORE</a>
                        </div>
                    </div>

                    <div class="practice-card">
                        <div class="practice-icon">📝</div>
                        <div class="practice-line"></div>
                        <div class="practice-info">
                            <h4><em>Corporate Commercial</em></h4>
                            <p>One of our key practice areas is corporate and commercial, which extends to various
                                sectors.</p>
                            <a href="corporate-commercial.php">READ MORE</a>
                        </div>
                    </div>

                    <div class="practice-card">
                        <div class="practice-icon">🤝</div>
                        <div class="practice-line"></div>
                        <div class="practice-info">
                            <h4><em>Dispute Resolution</em></h4>
                            <p>We work virtually in every area of dispute resolution and litigation strategy.</p>
                            <a href="dispute-resolution.php">READ MORE</a>
                        </div>
                    </div>

                    <div class="practice-card">
                        <div class="practice-icon">☂️</div>
                        <div class="practice-line"></div>
                        <div class="practice-info">
                            <h4><em>Litigation</em></h4>
                            <p>Our litigation practice is seen as a market leader. We advise clients on the entire
                                gamut.</p>
                            <a href="litigation.php">READ MORE</a>
                        </div>
                    </div>

                    <!-- <div class="practice-card">
                            <div class="practice-icon">💧</div>
                            <div class="practice-line"></div>
                            <div class="practice-info">
                                <h4><em>Energy, Oil and Gas</em></h4>
                                <p>We have significant experience and expertise in the Energy, Oil & Gas sector.</p>
                                <a href="#">READ MORE</a>
                            </div>
                        </div> -->

                    <div class="practice-card">
                        <div class="practice-icon">🏠</div>
                        <div class="practice-line"></div>
                        <div class="practice-info">
                            <h4><em>Real Estate</em></h4>
                            <p>We advise clients on increasingly diverse and complex matters in the real estate
                                space.</p>
                            <a href="#">READ MORE</a>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div><br><br>
    <!-- Footer -->
    <?php include('includes/footer.php');?>
</body>

</html>